<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/admin', 'Admin\LoginController@index')->name('admin');
Route::post('/admin/authenticate', 'Admin\LoginController@authenticate')->name('admin-authenticate');
Route::any('/logout','Auth\LoginController@logout')->name('logout');

Route::middleware(['auth:admin'])->group(function () {
    Route::any('/admin/create_admin', 'Admin\AdminController@create_admin');
    Route::any('/admin/change_password', 'Admin\AdminController@change_password');
    Route::any('/admin/profile', 'Admin\AdminController@profile');
    Route::any('/admin/add_staff_member', 'Admin\AdminController@add_staff_member');
    Route::any('/admin/resetpassword', 'Admin\AdminController@resetpassword');
    Route::any('/admin/add_member', 'Admin\AdminController@add_member');
    Route::any('/admin/update_profile', 'Admin\AdminController@update_profile');
    Route::any('/admin/get_staff_members', 'Admin\AdminController@get_staff_members');
    Route::any('/admin/view_staff_members', 'Admin\AdminController@view_staff_members');
    Route::any('/admin/check_email_id_exist', 'Admin\AdminController@check_email_id_exist');
    Route::any('/manage_staff/edit/{id}','Admin\AdminController@edit_staff_member');
    Route::any('/admin/manage_sitesettings', 'Admin\AdminController@site_settings'); 
    Route::any('/admin/update_sitesettings', 'Admin\AdminController@update_sitesettings'); 
    Route::get('/admin/logout', 'Admin\LoginController@logout')->name('admin-logout'); 
    

    Route::get('/dashboard', 'Admin\DashboardController@index')->name('dashboard');
    Route::get('/dashboard/get_users', 'Admin\DashboardController@get_users')->name('get-new-user-list');
    Route::get('/dashboard/get_ghost_users','Admin\DashboardController@get_ghost_users')->name('get-ghost-user-list');
    Route::get('/dashboard/get_orders','Admin\DashboardController@get_orders')->name('get-orders-list');

    Route::any('/vouchers/create_voucher', 'Admin\VouchersController@create_voucher');
    Route::any('/vouchers/insertupdatevoucher', 'Admin\VouchersController@insertupdatevoucher');
    Route::any('/vouchers/view_vouchers', 'Admin\VouchersController@index');
    Route::any('/vouchers/get_coupons', 'Admin\VouchersController@get_coupons');
    Route::any('/vouchers/edit_coupon/{id}', 'Admin\VouchersController@edit_coupon');
    Route::any('/vouchers/delete_voucher', 'Admin\VouchersController@delete_voucher');
    Route::any('vouchers/delete_multiple_vouchers','Admin\VouchersController@delete_multiple_vouchers');

    Route::any('/schedule_plans/create_schedule', 'Admin\SchedulesPlansController@create_schedule');
    Route::any('/schedule_plans/insertupdateplan', 'Admin\SchedulesPlansController@insertupdateplan');
    Route::any('/schedule_plans/view_plans', 'Admin\SchedulesPlansController@index');
    Route::any('/schedule_plans/get_plans', 'Admin\SchedulesPlansController@get_plans');
    Route::any('/schedule_plans/edit_plan/{id}', 'Admin\SchedulesPlansController@edit_plan');
    Route::any('/schedule_plans/delete_plan', 'Admin\SchedulesPlansController@delete_plan');

    Route::any('/faqs/create_faq', 'Admin\FaqsController@create_faq');
    Route::any('/faqs/insertupdatefaq', 'Admin\FaqsController@insertupdatefaq');
    Route::any('/faqs/view_faqs', 'Admin\FaqsController@index');
    Route::any('/faqs/get_faqs', 'Admin\FaqsController@get_faqs');
    Route::any('/faqs/edit_faq/{id}', 'Admin\FaqsController@edit_faq');
    Route::any('/faqs/delete_faqs', 'Admin\FaqsController@delete_faqs');
    Route::any('/faqs/delete_multiple_faqs', 'Admin\FaqsController@delete_multiple_faqs');

    Route::get('/manage_places/add', 'Admin\ManagePlaces@add_place')->name('add-place');
    Route::post('/manage_places/submit', 'Admin\ManagePlaces@submit_place')->name('submit-place');
    Route::get('/manage_places/view', 'Admin\ManagePlaces@view')->name('view-place');
    Route::get('/manage_places/get_places', 'Admin\ManagePlaces@get_places')->name('get-place-list');
    Route::get('/manage_places/edit/{id}', 'Admin\ManagePlaces@edit_place')->name('edit-place');
    Route::post('/manage_places/update', 'Admin\ManagePlaces@update_place')->name('update-place');
    Route::get('/manage_places/delete/{id}', 'Admin\ManagePlaces@delete_place')->name('delete-place');
    Route::any('/manage_places/delete_multiple_plans','Admin\ManagePlaces@delete_multiple_plans');

    Route::get('/manage_lacarte/add', 'Admin\ManageLaCarte@add')->name('add-la-carte');
    Route::post('/manage_lacarte/submit', 'Admin\ManageLaCarte@submit')->name('submit-la-carte');
    Route::get('/manage_lacarte/view', 'Admin\ManageLaCarte@view')->name('get-lacarte-list');
    Route::get('/manage_lacarte/get_la_carte', 'Admin\ManageLaCarte@get_la_carte')->name('get-lacarte-list');
    Route::get('/manage_lacarte/edit/{id}', 'Admin\ManageLaCarte@edit_lacarte')->name('edit-lacarte');
    Route::post('/manage_lacarte/update', 'Admin\ManageLaCarte@update_lacarte')->name('update-lacarte');
    Route::get('/manage_lacarte/delete/{id}', 'Admin\ManageLaCarte@delete_lacarte')->name('delete-lacarte');
    Route::any('/manage_lacarte/delete_multiple_lacarte','Admin\ManageLaCarte@delete_multiple_lacarte');

    Route::get('/manage_extras/add', 'Admin\ManageExtras@add')->name('add-extras');
    Route::post('/manage_extras/submit', 'Admin\ManageExtras@submit')->name('submit-extras');
    Route::get('/manage_extras/view', 'Admin\ManageExtras@view')->name('view-extras-list');
    Route::get('/manage_extras/get_extras', 'Admin\ManageExtras@get_extras')->name('get-extras');
    Route::get('/manage_extras/edit/{id}', 'Admin\ManageExtras@edit_extras')->name('edit-extras');
    Route::post('/manage_extras/update', 'Admin\ManageExtras@update_extras')->name('update-extras');
    Route::post('/manage_extras/delete', 'Admin\ManageExtras@delete_extras')->name('delete-extras');
    Route::any('/manage_extras/delete_multiple_extra','Admin\ManageExtras@delete_multiple_extra');

    Route::get('/manage_users/add', 'Admin\ManageUsers@add')->name('add-users');
    Route::post('/manage_users/submit', 'Admin\ManageUsers@submit')->name('submit-users');
    Route::get('/manage_users/view', 'Admin\ManageUsers@view')->name('view-users');
    Route::get('/manage_users/ghost_users', 'Admin\ManageUsers@ghost_users')->name('ghost-users');
    Route::get('/manage_users/get_users', 'Admin\ManageUsers@get_users')->name('get-users');
    Route::get('/manage_users/get_ghost_users','Admin\ManageUsers@get_ghost_users')->name('get-ghost-users');
    Route::get('/manage_users/edit/{id}', 'Admin\ManageUsers@edit_users')->name('edit-users');
    Route::post('/manage_users/update', 'Admin\ManageUsers@update_users')->name('update-users');
    Route::post('/manage_users/delete', 'Admin\ManageUsers@delete_users')->name('delete-users');
    Route::any('/manage_users/delete_multiple_users', 'Admin\ManageUsers@delete_multiple_users');
    
    Route::any('/orders/view', 'Admin\ManageOrders@view')->name('view-orders');
    Route::any('/orders/get_orders', 'Admin\ManageOrders@get_orders')->name('get-orders');
    Route::any('/orders/order_detail/{id}', 'Admin\ManageOrders@order_detail')->name('order-detail');
    Route::any('/orders/order/history/{id}/', 'Admin\ManageOrders@order_history')->name('admin-order-history');
    Route::post('/orders/change_status', 'Admin\ManageOrders@change_status')->name('change-order-status');
    
    Route::post('/orders/change_assign_order', 'Admin\ManageOrders@change_assign_order')->name('change-assign-order-status');
    Route::any('/orders/delete_orders','Admin\ManageOrders@delete_orders');
    

    Route::post('/manage_staff/delete', 'Admin\AdminController@delete_member')->name('delete-member');

    Route::any('/calendar', 'Admin\CalendarController@index')->name('calendar');

    Route::any('/orders/get', 'Admin\CalendarController@orders')->name('calendar-orders');

    Route::any('/admin/manage_dates', 'Admin\AdminController@manage_dates');
    Route::any('/admin/add_dates', 'Admin\AdminController@insert_dates');
    Route::any('/admin/get_dates','Admin\AdminController@get_dates');
    Route::any('/manage_dates/delete','Admin\AdminController@delete_date');

    Route::any('/email_template/add', 'Admin\EmailTemplate@add')->name('add-email-template');
    Route::any('/email_template/view', 'Admin\EmailTemplate@view')->name('view-email-template');
    Route::post('/email_template/submit', 'Admin\EmailTemplate@submit')->name('submit-email-template');
    Route::any('/email_template/get_template', 'Admin\EmailTemplate@get_template')->name('get-email-template');
    Route::any('/email_template/edit/{id}', 'Admin\EmailTemplate@edit')->name('/edit-email-template');
    Route::post('/email_template/delete', 'Admin\EmailTemplate@delete')->name('delete-email-template');
    Route::post('/email_template/update', 'Admin\EmailTemplate@update')->name('update-email-template');

    Route::any('/admin/manage_zipcode', 'Admin\AdminController@manage_zipcode');
    Route::any('/admin/add_zipcode', 'Admin\AdminController@insert_zipcode');
    Route::any('/admin/get_zipcodes','Admin\AdminController@get_zipcodes');
    Route::any('/manage_zipcode/delete','Admin\AdminController@delete_zipcode');
    Route::any('/manage_zipcode/check_zipcode','Admin\AdminController@check_zipcode');
    Route::any('/manage_dates/delete_dates','Admin\AdminController@delete_dates');
    Route::any('/manage_staff/delete_members','Admin\AdminController@delete_members');
    Route::any('/manage_zipcode/delete_zipcodes','Admin\AdminController@delete_zipcodes');
	
	Route::any('/manage_address/add','Admin\ManageAddress@add');
	Route::any('/manage_address/submit','Admin\ManageAddress@submit');
	Route::any('/manage_address/view','Admin\ManageAddress@view');
	Route::any('/manage_address/get_addresses','Admin\ManageAddress@get_addresses');
	Route::any('/manage_address/edit/{id}','Admin\ManageAddress@edit_address');
	Route::any('/manage_address/update','Admin\ManageAddress@update_address');
	Route::any('/manage_address/delete_address','Admin\ManageAddress@delete_address');
	Route::any('/manage_address/delete_multiple_address','Admin\ManageAddress@delete_multiple_address');
});



Route::get('/', function () {
    return view('welcome');
});

Route::fallback(function(){
    return redirect('/');
});

Route::get('/stripe', 'PaymentController@index');
Route::any('/charge', 'PaymentController@charge')->name('charge');

Auth::routes();
Route::get('/', 'HomeController@landingpage');
Route::get('/home', 'HomeController@index')->name('home');
Route::get('/testimonial', 'HomeController@testimonial')->name('testimonial');
Route::any('/home/get_related_bathrooms', 'HomeController@get_related_bathrooms');
Route::any('/home/submit_step1', 'HomeController@submit_step1');
Route::any('/home/get_final_total', 'HomeController@get_final_total');
Route::any('/home/get_profile_final_total', 'HomeController@get_profile_final_total');
Route::any('/home/set_address_info', 'HomeController@set_address_info');
Route::any('/home/set_billing_info', 'HomeController@set_billing_info');
Route::any('/home/set_account_info', 'HomeController@set_account_info');
Route::any('/home/place_order', 'HomeController@place_order');
Route::any('/home/check_all_session', 'HomeController@check_all_session');
Route::any('/home/check_email', 'HomeController@check_email');
Route::any('/home/check_voucher', 'HomeController@check_voucher');
Route::any('/home/confirmation', 'HomeController@upsell');
Route::any('/home/change_order_datetime', 'HomeController@change_order_datetime');
Route::any('/home/change_bedroom_bathrooms', 'HomeController@change_bedroom_bathrooms');
Route::get('/page3', 'HomeController@page3')->name('page3');
Route::get('/page2', 'HomeController@page2')->name('page2');
Route::post('/home/update_address_info', 'HomeController@update_address_info');
Route::post('/home/update_billing_info', 'HomeController@update_billing_info');
Route::post('/home/update_profile', 'HomeController@update_profile');
Route::any('/home/send_mail_to_ghost_users','HomeController@send_mail_to_ghost_users');

Route::post('/add_to_order', 'HomeController@add_to_order')->name('add_to_order');

Route::any('/reorder', 'CronController@reorder')->name('reorder');
Route::any('/home/get_active_dates','HomeController@get_active_dates');

Route::any('home/check_zipcode','HomeController@check_zipcode')->name('check-zipcode');
Route::any('/home/login_authenticate','HomeController@login_authenticate');
Route::any('order/history','OrderhistoryController@index')->name('order-history');